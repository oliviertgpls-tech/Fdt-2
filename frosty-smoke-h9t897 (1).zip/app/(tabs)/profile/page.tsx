export default function ProfilePage() {
  return (
    <section className="space-y-4">
      <h1 className="text-2xl font-semibold">Mon profil</h1>
      <p className="text-gray-600">Paramètres utilisateur (à venir).</p>
    </section>
  );
}
