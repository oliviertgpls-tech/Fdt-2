export default function RecipesPage() {
  return <div>Liste de recettes</div>;
}
