export default function LibraryPage() {
    return (
      <section className="space-y-4">
        <h1 className="text-2xl font-semibold">Ma bibliothèque</h1>
        <p className="text-gray-600">Tes favoris, collections, etc.</p>
      </section>
    );
  }